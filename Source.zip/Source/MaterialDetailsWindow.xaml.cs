﻿using Microsoft.Web.WebView2.Core;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Controls;

namespace MyLab_V2_WPF
{
    public partial class MaterialDetailsWindow : Window

    {
        private double zoomScale = 1.0;
        private const double MinZoom = 1.0;
        private const double MaxZoom = 3.0; // Prevents excessive growth
        private bool isZoomed = false;

        private TranslateTransform translateTransform = new TranslateTransform();
        public int? MATQNT { get; set; }
        public double? MCosturl { get; set; }
        public string? DatasheetUrl { get; set; }
        public string? ReferenceUrl { get; set; }

        public string? addfileurl1 { get; set; }
        public string? addfileurl2 { get; set; }
        public string? addfileurl3 { get; set; }
        public string? addfileurl4 { get; set; }
        public string? addfileurl5 { get; set; }

        public List<string> ImageUrls { get; set; } = new List<string>();
        private int currentImageIndex = 0;

        public MaterialDetailsWindow()
        {
            InitializeComponent();
            this.Loaded += MaterialDetailsWindow_Loaded;
        }

        private void Thumbnail_Click(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (sender is Image thumbnail && thumbnail.Source is BitmapImage bitmap)
            {
                imgMaterial.Source = new BitmapImage(new Uri(bitmap.UriSource.ToString()));
            }
        }


        private void Image_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            var scaleTransform = imgMaterial.RenderTransform as ScaleTransform ?? new ScaleTransform();
            double zoomFactor = e.Delta > 0 ? 1.2 : 0.8;

            zoomScale *= zoomFactor;
            zoomScale = Math.Clamp(zoomScale, MinZoom, MaxZoom); // Prevents image from getting too large

            scaleTransform.ScaleX = zoomScale;
            scaleTransform.ScaleY = zoomScale;
            imgMaterial.RenderTransform = scaleTransform;
            e.Handled = true;
        }

        // Move image when zoomed in
        private void Image_MouseMove(object sender, MouseEventArgs e)
        {
            if (!isZoomed) return;

            var position = e.GetPosition(imgMaterial);
            double xOffset = (position.X - imgMaterial.ActualWidth / 2) ;
            double yOffset = (position.Y - imgMaterial.ActualHeight / 2) ;

            translateTransform.X = -xOffset;
            translateTransform.Y = -yOffset;
            imgMaterial.RenderTransform = new TransformGroup
            {
                Children = { new ScaleTransform(zoomScale, zoomScale), translateTransform }
            };
        }

        // Toggle full zoom mode on left-click
        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            isZoomed = !isZoomed;
            zoomScale = isZoomed ? 2.0 : 1.0;

            var scaleTransform = new ScaleTransform(zoomScale, zoomScale);
            imgMaterial.RenderTransform = scaleTransform;
        }

        private async void MaterialDetailsWindow_Loaded(object sender, RoutedEventArgs e)
        {
            if (MATQNT < 8)
            {
                txt2.Visibility = Visibility.Collapsed;
                txt3.Visibility = Visibility.Visible;
            }
            
            imgMaterial.MaxWidth = 200;
            imgMaterial.MaxHeight = 200;

            if (ImageUrls.Count > 0)
            {
                currentImageIndex = 0; // Ensure we start from the first image
                imgMaterial.Source = new BitmapImage(new Uri(ImageUrls[currentImageIndex]));
            }
            else
            {                
                MessageBox.Show("No Images Available.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            await webViewer.EnsureCoreWebView2Async();
            if (!string.IsNullOrEmpty(DatasheetUrl))
            {
                webViewer.Source = new Uri(DatasheetUrl);
            }
            else
            {
                MessageBox.Show("No Datasheet Available.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        private void btnPrevImage_Click(object sender, RoutedEventArgs e)
        {
            if (ImageUrls.Count > 0)
            {
                currentImageIndex = (currentImageIndex - 1 + ImageUrls.Count) % ImageUrls.Count;
                imgMaterial.Source = new BitmapImage(new Uri(ImageUrls[currentImageIndex]));
            }
        }

        private void btnNextImage_Click(object sender, RoutedEventArgs e)
        {
            if (ImageUrls.Count > 0)
            {
                currentImageIndex = (currentImageIndex + 1) % ImageUrls.Count;
                imgMaterial.Source = new BitmapImage(new Uri(ImageUrls[currentImageIndex]));
            }
        }


        private void btnViewDatasheet_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(DatasheetUrl))
            {
                webViewer.Source = new Uri(DatasheetUrl);
            }
        }

        private void btnViewReference_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(ReferenceUrl))
            {
                webViewer.Source = new Uri(ReferenceUrl);
            }
            else
            {
                MessageBox.Show("No Reference Available.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void btnViewadd1_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(addfileurl1))
            {
                webViewer.Source = new Uri(addfileurl1);
            }
            else
            {
                MessageBox.Show("No Additonal File 1 Available.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void btnViewadd2_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(addfileurl2))
            {
                webViewer.Source = new Uri(addfileurl2);
            }
            else
            {
                MessageBox.Show("No Additonal File 2 Available.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void btnViewadd3_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(addfileurl3))
            {
                webViewer.Source = new Uri(addfileurl3);
            }
            else
            {
                MessageBox.Show("No Additonal File 3 Available.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void btnViewadd4_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(addfileurl4))
            {
                webViewer.Source = new Uri(addfileurl4);
            }
            else
            {
                MessageBox.Show("No Additonal File 4 Available.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void btnViewadd5_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(addfileurl5))
            {
                webViewer.Source = new Uri(addfileurl5);
            }
            else
            {
                MessageBox.Show("No Additonal File 5 Available.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


    }
}
