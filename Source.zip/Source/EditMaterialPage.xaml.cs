﻿using System;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Newtonsoft.Json.Linq;
using MyLab_V2_WPF;
using Microsoft.Win32;
using System.Globalization;
using System.Windows.Data;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.IO;


namespace MyLab_V2_WPF
{
   
    public partial class EditMaterialPage : Page
    {
        private string GitHubUsername => (Application.Current as App)?.GitHubUsername ?? "";
        private string PersonalAccessToken => (Application.Current as App)?.PersonalAccessToken ?? "";
        private readonly HttpClient _httpClient = new HttpClient();

        public EditMaterialPage()
        {
            InitializeComponent();
        }

        private void MaterialType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string MaterialTypecheck = (MaterialType.SelectedItem as ComboBoxItem)?.Content.ToString();
            if (MaterialTypecheck == "General Document" || MaterialTypecheck == "Design Document" || MaterialTypecheck == "Analysis/Test Report")
            {
                ImageLinksTextBox.Text = "https://upload.wikimedia.org/wikipedia/commons/d/d6/Files_App_icon_iOS.png";
                imagpanel.Visibility = Visibility.Collapsed;
                MaterialName.Visibility = Visibility.Collapsed;
                MaterialName1.Visibility = Visibility.Visible;

                MaterialDescription.Visibility = Visibility.Collapsed;
                MaterialDescription1.Visibility = Visibility.Visible;

                DatasheetLink.Visibility = Visibility.Collapsed;
                DatasheetLink1.Visibility = Visibility.Visible;

                ReferenceLink.Visibility = Visibility.Collapsed;
                ReferenceLink1.Visibility = Visibility.Visible;

                AdditionalFiles.Visibility = Visibility.Collapsed;
                AdditionalFiles1.Visibility = Visibility.Visible;

                PartNumber.Visibility = Visibility.Visible;
                PartNumber1.Visibility = Visibility.Collapsed;

                Manufacturer.Visibility = Visibility.Visible;
                Manufacturer1.Visibility = Visibility.Collapsed;

                Quantity.Visibility = Visibility.Visible;
                Quantity1.Visibility = Visibility.Collapsed;

                QualityStatus.Visibility = Visibility.Visible;
                QualityStatus1.Visibility = Visibility.Collapsed;

                Location.Visibility = Visibility.Visible;
                Location1.Visibility = Visibility.Collapsed;
            }
            else if (MaterialTypecheck == "Electronic Material" || MaterialTypecheck == "Electrical Material" || MaterialTypecheck == "Machanical Material")
            {
                
                imagpanel.Visibility = Visibility.Visible;
                MaterialName.Visibility = Visibility.Collapsed;
                MaterialName1.Visibility = Visibility.Visible;

                PartNumber.Visibility = Visibility.Collapsed;
                PartNumber1.Visibility = Visibility.Visible;

                Manufacturer.Visibility = Visibility.Collapsed;
                Manufacturer1.Visibility = Visibility.Visible;

                MaterialDescription.Visibility = Visibility.Collapsed;
                MaterialDescription1.Visibility = Visibility.Visible;

                Quantity.Visibility = Visibility.Collapsed;
                Quantity1.Visibility = Visibility.Visible;

                QualityStatus.Visibility = Visibility.Collapsed;
                QualityStatus1.Visibility = Visibility.Visible;

                Location.Visibility = Visibility.Collapsed;
                Location1.Visibility = Visibility.Visible;

                DatasheetLink.Visibility = Visibility.Collapsed;
                DatasheetLink1.Visibility = Visibility.Visible;

                ReferenceLink.Visibility = Visibility.Visible;
                ReferenceLink1.Visibility = Visibility.Collapsed;

                AdditionalFiles.Visibility = Visibility.Visible;
                AdditionalFiles1.Visibility = Visibility.Collapsed;

                MaterialImageLinks.Visibility = Visibility.Collapsed;
                MaterialImageLinks1.Visibility = Visibility.Visible;
            }
            else
            {
                ImageLinksTextBox.Text = "";
                imagpanel.Visibility = Visibility.Visible;
                MaterialName.Visibility = Visibility.Collapsed;
                MaterialName1.Visibility = Visibility.Visible;

                MaterialDescription.Visibility = Visibility.Collapsed;
                MaterialDescription1.Visibility = Visibility.Visible;

                PartNumber.Visibility = Visibility.Visible;
                PartNumber1.Visibility = Visibility.Collapsed;

                Manufacturer.Visibility = Visibility.Visible;
                Manufacturer1.Visibility = Visibility.Collapsed;

                Quantity.Visibility = Visibility.Visible;
                Quantity1.Visibility = Visibility.Collapsed;

                QualityStatus.Visibility = Visibility.Visible;
                QualityStatus1.Visibility = Visibility.Collapsed;

                Location.Visibility = Visibility.Visible;
                Location1.Visibility = Visibility.Collapsed;

                DatasheetLink.Visibility = Visibility.Visible;
                DatasheetLink1.Visibility = Visibility.Collapsed;

                ReferenceLink.Visibility = Visibility.Visible;
                ReferenceLink1.Visibility = Visibility.Collapsed;

                AdditionalFiles.Visibility = Visibility.Visible;
                AdditionalFiles1.Visibility = Visibility.Collapsed;

                MaterialImageLinks.Visibility = Visibility.Visible;
                MaterialImageLinks1.Visibility = Visibility.Collapsed;
            }

        }
        private void BrowseRef_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select a Reference File",
                Filter = "PDF Files (*.pdf)|*.pdf",
                DefaultExt = ".pdf"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Refpath.Text = openFileDialog.FileName; // Set selected path in TextBox
            }
        }


        private void BrowseDS_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select a Datasheet File",
                Filter = "PDF Files (*.pdf)|*.pdf",
                DefaultExt = ".pdf"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Datasheetpath.Text = openFileDialog.FileName; // Set selected path in TextBox
            }
        }


        private void BrowseAdd1_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select a Additional File 1",
                Filter = "All Files (*.*)|*.*",
                DefaultExt = ""
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Addpath1.Text = openFileDialog.FileName; // Set selected path in TextBox
            }
        }

        private void BrowseAdd2_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select a Additional File 1",
                Filter = "All Files (*.*)|*.*",
                DefaultExt = ""
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Addpath2.Text = openFileDialog.FileName; // Set selected path in TextBox
            }
        }

        private void BrowseAdd3_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select a Additional File 1",
                Filter = "All Files (*.*)|*.*",
                DefaultExt = ""
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Addpath3.Text = openFileDialog.FileName; // Set selected path in TextBox
            }
        }

        private void BrowseAdd4_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select a Additional File 1",
                Filter = "All Files (*.*)|*.*",
                DefaultExt = ""
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Addpath4.Text = openFileDialog.FileName; // Set selected path in TextBox
            }
        }

        private void BrowseAdd5_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select a Additional File 1",
                Filter = "All Files (*.*)|*.*",
                DefaultExt = ""
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Addpath5.Text = openFileDialog.FileName; // Set selected path in TextBox
            }
        }


        private void BrowseImg_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select a Material Image",
                Filter = "Image Files (*.jpg;*.jpeg;*.png;*.bmp;*.gif)|*.jpg;*.jpeg;*.png;*.bmp;*.gif",
                DefaultExt = ".jpg"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Imagepath.Text = openFileDialog.FileName; // Set selected path in TextBox
            }
        }

        private void BrowseImg2_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Select a Material Image",
                Filter = "Image Files (*.jpg;*.jpeg;*.png;*.bmp;*.gif)|*.jpg;*.jpeg;*.png;*.bmp;*.gif",
                DefaultExt = ".jpg"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                Image2path.Text = openFileDialog.FileName; // Set selected path in TextBox
            }
        }








        private async void FetchDataButton_Click(object sender, RoutedEventArgs e)
        {
            string repoName = MIDTextBox.Text;
            if (string.IsNullOrEmpty(repoName))
            {
                MessageBox.Show("Please enter a valid Material ID.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var jsonData = await FetchJsonFromRepo(repoName);
                PopulateFields(jsonData);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error Fetching material data: {ex.Message}");
            }
        }




        private async Task<string> UploadFileToGitHub(string repoName, string filePath)
        {
            string fileName = Path.GetFileName(filePath);
            string url = $"https://api.github.com/repos/{GitHubUsername}/{repoName}/contents/{fileName}";

            byte[] fileBytes = File.ReadAllBytes(filePath);
            string base64Content = Convert.ToBase64String(fileBytes);

            var requestBody = new
            {
                message = $"Added {fileName}",
                content = base64Content
            };

            var request = new HttpRequestMessage(HttpMethod.Put, url);
            request.Headers.Authorization = new AuthenticationHeaderValue("token", PersonalAccessToken);
            request.Headers.Add("User-Agent", "MyLabApp");
            request.Content = new StringContent(JsonConvert.SerializeObject(requestBody), Encoding.UTF8, "application/json");


            HttpResponseMessage response = await _httpClient.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                return $"https://raw.githubusercontent.com/{GitHubUsername}/{repoName}/main/{fileName}";
            }
            return string.Empty;
        }






        private async void SaveUpdatesButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadingOverlay.Visibility = Visibility.Visible;
                string repoName = MIDTextBox.Text;
                status1.Text = "Started Uploading Files...";


                if (!string.IsNullOrEmpty(Datasheetpath.Text))
                {
                    string pdfUrl = await UploadFileToGitHub(repoName, Datasheetpath.Text);
                    DatasheetLinkTextBox.Text = $"https://docs.google.com/viewerng/viewer?url={Uri.EscapeDataString(pdfUrl)}";
                }
                if (!string.IsNullOrEmpty(Refpath.Text))
                {
                    string refUrl = await UploadFileToGitHub(repoName, Refpath.Text);
                    RefLinkTextBox.Text = $"https://docs.google.com/viewerng/viewer?url={Uri.EscapeDataString(refUrl)}";
                }
                if (!string.IsNullOrEmpty(Imagepath.Text))
                {
                    string imgUrl = await UploadFileToGitHub(repoName, Imagepath.Text);
                    ImageLinksTextBox.Text = imgUrl;
                }
                if (!string.IsNullOrEmpty(Image2path.Text))
                {
                    string imgUrl2 = await UploadFileToGitHub(repoName, Image2path.Text);
                    ImageLinksTextBox.Text += $", {imgUrl2}";
                }
                status1.Text = "Genarating Accessible...";
                if (!string.IsNullOrEmpty(Addpath1.Text))
                {
                    string add1url = await UploadFileToGitHub(repoName, Addpath1.Text);
                    AdditionalFilesTextBox1.Text = $"https://docs.google.com/viewerng/viewer?url={Uri.EscapeDataString(add1url)}";
                }
                if (!string.IsNullOrEmpty(Addpath2.Text))
                {
                    string add2url = await UploadFileToGitHub(repoName, Addpath2.Text);
                    AdditionalFilesTextBox2.Text = $"https://docs.google.com/viewerng/viewer?url={Uri.EscapeDataString(add2url)}";
                }
                if (!string.IsNullOrEmpty(Addpath3.Text))
                {
                    string add3url = await UploadFileToGitHub(repoName, Addpath3.Text);
                    AdditionalFilesTextBox3.Text = $"https://docs.google.com/viewerng/viewer?url={Uri.EscapeDataString(add3url)}";
                }
                if (!string.IsNullOrEmpty(Addpath4.Text))
                {
                    string add4url = await UploadFileToGitHub(repoName, Addpath4.Text);
                    AdditionalFilesTextBox4.Text = $"https://docs.google.com/viewerng/viewer?url={Uri.EscapeDataString(add4url)}";
                }
                if (!string.IsNullOrEmpty(Addpath5.Text))
                {
                    string add5url = await UploadFileToGitHub(repoName, Addpath5.Text);
                    AdditionalFilesTextBox5.Text = $"https://docs.google.com/viewerng/viewer?url={Uri.EscapeDataString(add5url)}";
                }

                var updatedJson = GenerateJsonFromInput();
                await UploadJsonToRepo(repoName, "db.json", updatedJson);
                status1.Text = "Material Uploading to DB...";
                LoadingOverlay.Visibility = Visibility.Collapsed;

                MessageBox.Show("Material details updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                LoadingOverlay.Visibility = Visibility.Collapsed;
                MessageBox.Show($"Error saving updates: {ex.Message}");
            }
        }

        private async Task<JObject> FetchJsonFromRepo(string repoName)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {PersonalAccessToken}");
                client.DefaultRequestHeaders.Add("User-Agent", "RepoEditorApp");

                string repoApiUrl = $"https://api.github.com/repos/{GitHubUsername}/{repoName}/contents/db.json";
                var response = await client.GetAsync(repoApiUrl);

                if (!response.IsSuccessStatusCode)
                    throw new Exception("Failed to fetch JSON data.");

                var jsonResponse = JObject.Parse(await response.Content.ReadAsStringAsync());
                string decodedContent = Encoding.UTF8.GetString(Convert.FromBase64String(jsonResponse["content"].ToString()));
                return JObject.Parse(decodedContent);
            }
        }

        private void PopulateFields(JObject jsonData)
        {
            var material = jsonData["inventory"]?.FirstOrDefault();
            if (material == null) return;

            MaterialNameTextBox.Text = material["MaterialTitle"]["Name"]?.ToString();
            PartNumberTextBox.Text = material["MaterialTitle"]["PN"]?.ToString();
            ManufacturerTextBox.Text = material["MaterialTitle"]["MF"]?.ToString();
            DescriptionTextBox.Text = material["MD"]?.ToString();
            MaterialTypeTextBox.Text = material["MT"]?.ToString();
            QuantityTextBox.Text = material["MQNT"]?.ToString();
            UnitCostTextBox.Text = material["MCost"]?.ToString();
            TagTextBox.Text = material["MQATG"]?.ToString();
            LocationTextBox.Text = material["ML"]?.ToString();
            DatasheetLinkTextBox.Text = material["MDS"]?.ToString();
            AdditionalFilesTextBox1.Text = material["MAF1"]?.ToString();
            AdditionalFilesTextBox2.Text = material["MAF2"]?.ToString();
            AdditionalFilesTextBox3.Text = material["MAF3"]?.ToString();
            AdditionalFilesTextBox4.Text = material["MAF4"]?.ToString();
            AdditionalFilesTextBox5.Text = material["MAF5"]?.ToString();
            RefLinkTextBox.Text = material["MR"]?.ToString();
            
            ImageLinksTextBox.Text = string.Join(", ", material["MaterialImages"].Select(x => x.ToString()));

            string targetText1 = MaterialTypeTextBox.Text;
            string targetText2 = TagTextBox.Text;
            foreach (ComboBoxItem item in MaterialType.Items)
            {
                if (item.Content.ToString().Equals(targetText1, StringComparison.OrdinalIgnoreCase))
                {
                    MaterialType.SelectedItem = item;
                    break;
                }
            }
            foreach (ComboBoxItem item1 in TagCombo.Items)
            {
                if (item1.Content.ToString().Equals(targetText2, StringComparison.OrdinalIgnoreCase))
                {
                    TagCombo.SelectedItem = item1;
                    break;
                }
            }

        }

        private JObject GenerateJsonFromInput()
        {
            string MaterialTypeText = MaterialTypeTextBox.Text;
            string MaterialTag = TagTextBox.Text;
            if (MaterialType.SelectedItem is ComboBoxItem selectedItem)
            {
                MaterialTypeText = selectedItem.Content.ToString();
            }
            if (TagCombo.SelectedItem is ComboBoxItem selectedItem1)
            {
                MaterialTag = selectedItem1.Content.ToString();
            }

            var imageLinks = ImageLinksTextBox.Text.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                                   .Select(link => link.Trim());

            return new JObject(
                new JProperty("inventory", new JArray(
                    new JObject(
                        new JProperty("MaterialTitle", new JObject(
                            new JProperty("Name", MaterialNameTextBox.Text),
                            new JProperty("PN", PartNumberTextBox.Text),
                            new JProperty("MF", ManufacturerTextBox.Text)
                        )),
                        new JProperty("MID", MIDTextBox.Text),
                        new JProperty("MD", DescriptionTextBox.Text),
                        new JProperty("MT", MaterialTypeText),
                        new JProperty("MQNT", int.TryParse(QuantityTextBox.Text, out var quantity) ? quantity : 0),
                        new JProperty("MCost", decimal.TryParse(UnitCostTextBox.Text, out var UnitCostout) ? UnitCostout : 0m),
                        new JProperty("MQATG", MaterialTag),
                        new JProperty("ML", LocationTextBox.Text),
                        new JProperty("MDS", DatasheetLinkTextBox.Text),
                        new JProperty("MAF1", AdditionalFilesTextBox1.Text),
                        new JProperty("MAF2", AdditionalFilesTextBox2.Text),
                        new JProperty("MAF3", AdditionalFilesTextBox3.Text),
                        new JProperty("MAF4", AdditionalFilesTextBox4.Text),
                        new JProperty("MAF5", AdditionalFilesTextBox5.Text),
                        new JProperty("MR", RefLinkTextBox.Text),
                        new JProperty("MaterialImages", new JArray(imageLinks))
                    )
                ))
            );
        }

        private async Task UploadJsonToRepo(string repoName, string filePath, JObject jsonData)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {PersonalAccessToken}");
                client.DefaultRequestHeaders.Add("User-Agent", "RepoEditorApp");

                string repoApiUrl = $"https://api.github.com/repos/{GitHubUsername}/{repoName}/contents/{filePath}";

                // Fetch current file SHA (GitHub requires SHA for updates)
                var shaResponse = await client.GetAsync(repoApiUrl);
                string shaResponseBody = await shaResponse.Content.ReadAsStringAsync();
                Console.WriteLine($"SHA API Response: {shaResponseBody}");

                if (!shaResponse.IsSuccessStatusCode)
                {
                    throw new Exception("Failed to fetch existing file SHA. Make sure the file exists.");
                }

                var shaJson = JObject.Parse(shaResponseBody);
                string fileSha = shaJson["sha"].ToString();

                // Prepare content data
                var contentData = new
                {
                    message = "Updating JSON data",
                    content = Convert.ToBase64String(Encoding.UTF8.GetBytes(jsonData.ToString())),
                    sha = fileSha // Required for updating an existing file
                };

                var content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(contentData), Encoding.UTF8, "application/json");
                Console.WriteLine($"Uploading JSON to: {repoApiUrl}");
                Console.WriteLine($"Payload: {Newtonsoft.Json.JsonConvert.SerializeObject(contentData)}");

                var response = await client.PutAsync(repoApiUrl, content);
                string responseBody = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"API Response: {responseBody}");

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception($"Failed to update JSON file: {responseBody}");
                }

                Console.WriteLine($"JSON file updated successfully in {repoName}.");
            }
        }

    }
}
