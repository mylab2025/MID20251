﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using MyLab_V2_WPF;
using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net.NetworkInformation;
using System.Diagnostics;
using System.Windows.Documents;
using System.Windows.Media;
using System.IO;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using System.Diagnostics;
using PdfSharp.Drawing.Layout;
using PdfSharp.Drawing;
using System.Reflection;




namespace MyLab_V2_WPF
{
    public partial class MainWindow : Window
    {
        private bool isLoadingNotes = false;


        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
            LoadingOverlay.Visibility = Visibility.Visible;

            ShowDashboard();
            LoadStoredCredentials();
            LoadDashboardData();
            LoadInventoryGrowthChart();
            CheckConnectionAndSpeed();

        }

        private void HighlightSelectedText(Color color)
        {
            if (!keepnotes.Selection.IsEmpty)
            {
                keepnotes.Selection.ApplyPropertyValue(TextElement.BackgroundProperty, new SolidColorBrush(color));
            }
        }

        private void HighlightRed_Click(object sender, RoutedEventArgs e)
        {
            HighlightSelectedText(Colors.OrangeRed);
        }

        private void HighlightYellow_Click(object sender, RoutedEventArgs e)
        {
            HighlightSelectedText(Colors.Yellow);
        }

        private void HighlightGreen_Click(object sender, RoutedEventArgs e)
        {
            HighlightSelectedText(Colors.LightGreen);
        }

        private void HighlightBlue_Click(object sender, RoutedEventArgs e)
        {
            HighlightSelectedText(Colors.DodgerBlue);
        }

        private void ClearHighlight_Click(object sender, RoutedEventArgs e)
        {
            HighlightSelectedText(Colors.Transparent);
        }


        private void keepnotes_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (isLoadingNotes) return;
            string noteText = new TextRange(keepnotes.Document.ContentStart, keepnotes.Document.ContentEnd).Text;
            SaveNotes();
            // Remove whitespace and check if there's actual content
            if (string.IsNullOrWhiteSpace(noteText) || noteText.Trim() == "")
            {
                txtPlaceholder.Visibility = Visibility.Visible;
            }
            else
            {
                txtPlaceholder.Visibility = Visibility.Collapsed;
                
            }
        }
        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            LoadNotes();                     // ✅ Now the RichTextBox is fully loaded
            keepnotes_TextChanged(null, null);
        }


        private string GetNotesFilePath()
        {
            string folder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string appFolder = Path.Combine(folder, "MyLab");

            // Create folder if it doesn't exist
            if (!Directory.Exists(appFolder))
            {
                Directory.CreateDirectory(appFolder);
            }

            return Path.Combine(appFolder, "Keepnotes.xamlpkg");
        }


        private void SaveNotes()
        {
            string path = GetNotesFilePath();
            using (FileStream fs = new FileStream(path, FileMode.Create))
            {
                TextRange range = new TextRange(keepnotes.Document.ContentStart, keepnotes.Document.ContentEnd);
                range.Save(fs, DataFormats.XamlPackage);  // ✅ Saves formatting

            }
        }


        private void LoadNotes()
        {
            string path = GetNotesFilePath();
            if (File.Exists(path))
            {
                try
                {
                    isLoadingNotes = true; // 👈 Stop SaveNotes() while loading

                    using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read))
                    {
                        TextRange range = new TextRange(keepnotes.Document.ContentStart, keepnotes.Document.ContentEnd);
                        range.Load(fs, DataFormats.XamlPackage);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed to load notes.\n" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    isLoadingNotes = false;
                }
            }
        }



        private void Bold_Click(object sender, RoutedEventArgs e)
        {
            ToggleFormatting(TextElement.FontWeightProperty, FontWeights.Bold);
        }

        private void Italic_Click(object sender, RoutedEventArgs e)
        {
            ToggleFormatting(TextElement.FontStyleProperty, FontStyles.Italic);
        }

        private void Underline_Click(object sender, RoutedEventArgs e)
        {
            if (!keepnotes.Selection.IsEmpty)
            {
                TextRange range = new TextRange(keepnotes.Selection.Start, keepnotes.Selection.End);
                object currentValue = range.GetPropertyValue(Inline.TextDecorationsProperty);

                // Check if underline is already applied
                if (currentValue == DependencyProperty.UnsetValue || currentValue == null || !TextDecorationsMatch(currentValue, TextDecorations.Underline))
                {
                    range.ApplyPropertyValue(Inline.TextDecorationsProperty, TextDecorations.Underline);
                }
                else
                {
                    range.ApplyPropertyValue(Inline.TextDecorationsProperty, null);
                }
            }
        }

        private bool TextDecorationsMatch(object current, TextDecorationCollection target)
        {
            if (current is TextDecorationCollection currentCollection)
            {
                // Compare count and elements
                if (currentCollection.Count != target.Count) return false;

                for (int i = 0; i < target.Count; i++)
                {
                    if (!currentCollection.Contains(target[i]))
                        return false;
                }

                return true;
            }

            return false;
        }


        private void ToggleFormatting(DependencyProperty property, object value)
        {
            if (!keepnotes.Selection.IsEmpty)
            {
                object current = keepnotes.Selection.GetPropertyValue(property);

                bool isActive = current != DependencyProperty.UnsetValue && current.Equals(value);

                object resetValue;

                if (property == TextElement.FontWeightProperty)
                    resetValue = FontWeights.Normal;
                else if (property == TextElement.FontStyleProperty)
                    resetValue = FontStyles.Normal;
                else if (property == Inline.TextDecorationsProperty)
                    resetValue = null;
                else
                    resetValue = null; // fallback for any unknowns

                keepnotes.Selection.ApplyPropertyValue(property, isActive ? resetValue : value);
            }
        }



        private void ExportPdf_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "PDF Files (*.pdf)|*.pdf",
                FileName = "MyLabNotes"
            };

            if (dlg.ShowDialog() == true)
            {
                try
                {
                    string noteText = new TextRange(keepnotes.Document.ContentStart, keepnotes.Document.ContentEnd).Text;

                    PdfDocument pdf = new PdfDocument();
                    pdf.Info.Title = "MyLab Notes";

                    // Setup fonts
                    XFont font = new XFont("Segoe UI", 12, XFontStyleEx.Regular);
                    XFont boldFont = new XFont("Segoe UI", 14, XFontStyleEx.Bold);
                    XFont italicFont = new XFont("Segoe UI", 12, XFontStyleEx.Italic);

                    // Define additional fonts for header, body, and footer
                    XFont headerFont = new XFont("Segoe UI", 16, XFontStyleEx.Bold);
                    XFont footerFont = new XFont("Segoe UI", 10, XFontStyleEx.Italic);
                    XFont bodyFont = new XFont("Segoe UI", 12, XFontStyleEx.Regular);

                    double margin = 40;
                    double headerHeight = 60; // Increased header height for logo and text
                    double footerHeight = 30;
                    double y = margin + headerHeight;

                    // Path to the logo image inside your project (relative path)
                    string logoPath = "/logo.png";// Adjust this to match the relative path of your logo

                    // Helper function to start a new page
                    void CreateNewPage(out PdfPage page, out XGraphics gfx, out XTextFormatter tf)
                    {
                        page = pdf.AddPage();
                        gfx = XGraphics.FromPdfPage(page); 
                        tf = new XTextFormatter(gfx);

                        try
                        {
                            // Adjust the namespace and image name to match your project
                            var assembly = Assembly.GetExecutingAssembly();
                            string resourceName = "MyLab_V2_WPF.Images.logo.png"; // ⚠️ Use your actual default namespace + folder + file name

                            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                            {
                                if (stream != null)
                                {
                                    XImage logo = XImage.FromStream(stream);
                                    gfx.DrawImage(logo, 10, 10, 50, 50);
                                }
                                else
                                {
                                    MessageBox.Show("Embedded logo resource not found:\n" + resourceName);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error loading embedded logo:\n" + ex.Message);
                        }

                        // Header text on the right side of the logo
                        gfx.DrawString("MyLab Notes", headerFont, XBrushes.Gray, new XRect(margin + 440, margin, page.Width, headerHeight), XStringFormats.TopLeft);

                        // Footer
                        gfx.DrawString("Version: 3.0.0", footerFont, XBrushes.Gray,
                                       new XRect(10, page.Height - footerHeight, page.Width, footerHeight), XStringFormats.BottomLeft);

                        // Footer2
                        gfx.DrawString("“A Smart Inventory Management Tool”", footerFont, XBrushes.Gray,
                                       new XRect(-10, page.Height - footerHeight, page.Width, footerHeight), XStringFormats.BottomRight);
                    }

                    CreateNewPage(out PdfPage page, out XGraphics gfx, out XTextFormatter layout);

                    double lineHeight = bodyFont.GetHeight();
                    var lines = noteText.Split('\n');

                    foreach (var line in lines)
                    {
                        layout.DrawString(line.TrimEnd(), bodyFont, XBrushes.Black,
                            new XRect(margin, y, page.Width - 2 * margin, page.Height - margin - footerHeight),
                            XStringFormats.TopLeft);
                        y += lineHeight;

                        if (y + lineHeight > page.Height - margin - footerHeight)
                        {
                            CreateNewPage(out page, out gfx, out layout);
                            y = margin + headerHeight;
                        }
                    }

                    pdf.Save(dlg.FileName);
                    MessageBox.Show("PDF Exported!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                    Process.Start(new ProcessStartInfo(dlg.FileName) { UseShellExecute = true });
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error exporting PDF:\n" + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }







        private void ExportTxt_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog dlg = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "Text Files (*.txt)|*.txt",
                FileName = "MyLabNotes"
            };

            if (dlg.ShowDialog() == true)
            {
                string plainText = new TextRange(keepnotes.Document.ContentStart, keepnotes.Document.ContentEnd).Text;
                File.WriteAllText(dlg.FileName, plainText);
                MessageBox.Show("Exported as .txt!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }


        private async void CheckConnectionAndSpeed()
        {
            bool isConnected = NetworkInterface.GetIsNetworkAvailable();
            string connectionStatus = isConnected ? " Stable" : "Disconnected";
            string speedText = "--";
            int speedKbps = 0;

            if (isConnected)
            {
                speedText = await GetConnectionSpeedInKbps();
            }

            // Find the TextBlocks in your UI and update them                                  
                        status.Text = $"Status: {connectionStatus}";          
                        speed.Text = $"Speed: {speedText}  Kb/sec...";
            int.TryParse(speedText, out speedKbps);
            if (speedKbps > 500) {
                status.Text = $"Status: Good";
            }
            if (speedKbps < 100)
            {

                status.Text = $"Status: Poor";
                LoadingOverlay.Visibility = Visibility.Collapsed;
            }
            if (speedKbps > 2000)
            {
                status.Text = $"Status: Great!";
            }
        }

        private async Task<string> GetConnectionSpeedInKbps()
        {
            string githubUsername = Settings.Default.GitHubUsername;

            try
            {
                using HttpClient client = new HttpClient();
                var url = $"https://raw.githubusercontent.com/{githubUsername}/test/main/test100kb.txt"; // ~100KB test file
                var stopwatch = Stopwatch.StartNew();

                var data = await client.GetByteArrayAsync(url);

                stopwatch.Stop();

                double seconds = stopwatch.Elapsed.TotalSeconds;
                double kilobits = data.Length * 8.0 / 1024;
                double kbps = kilobits / seconds;

                return ((int)kbps).ToString();
            }
            catch
            {
                return "0.0";
            }
        }

        public class DashboardViewModel
        {
            public ChartValues<int> InventoryData { get; set; }
            public List<string> TimeLabels { get; set; }

            public DashboardViewModel()
            {
                InventoryData = new ChartValues<int>();
                TimeLabels = new List<string>();
            }
        }

        public async Task LoadInventoryGrowthChart()
        {
            chart1.Visibility = Visibility.Visible;
            string githubUsername = Settings.Default.GitHubUsername;
            string personalAccessToken = Settings.Default.PersonalAccessToken;
            string apiUrl = $"https://api.github.com/users/{githubUsername}/repos";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("User-Agent", "MyLabApp");
                    client.DefaultRequestHeaders.Add("Authorization", $"Bearer {personalAccessToken}");

                    string reposJson = await client.GetStringAsync(apiUrl);
                    JsonDocument reposDoc = JsonDocument.Parse(reposJson);

                    Dictionary<string, int> materialsByMonth = new Dictionary<string, int>();

                    foreach (var repo in reposDoc.RootElement.EnumerateArray())
                    {
                        if (repo.TryGetProperty("created_at", out JsonElement createdAtElement))
                        {
                            DateTime createdAt = DateTime.Parse(createdAtElement.GetString());
                            string month = createdAt.ToString("yyyy-MM-dd");

                            if (!materialsByMonth.ContainsKey(month))
                                materialsByMonth[month] = 0;

                            materialsByMonth[month]++;
                        }
                    }

                    var sortedData = materialsByMonth.OrderBy(k => k.Key);
                    var viewModel = new DashboardViewModel();

                    foreach (var entry in sortedData)
                    {
                        viewModel.TimeLabels.Add(entry.Key);
                        viewModel.InventoryData.Add(entry.Value);
                    }

                    Dispatcher.Invoke(() =>
                    {
                        InventoryChart.DataContext = viewModel;
                    });
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show($"Error loading chart: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void SaveCredentialsButton_Click(object sender, RoutedEventArgs e)
        {
            Settings.Default.GitHubUsername = GitHubUsernameTextBox.Text;
            Settings.Default.PersonalAccessToken = PersonalAccessTokenTextBox.Password;
            Settings.Default.Save();
            LoadDashboardData();
            LoadInventoryGrowthChart();

            MessageBox.Show("Credentials saved successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            CheckConnectionAndSpeed();
        }

        private void LoadStoredCredentials()
        {
            GitHubUsernameTextBox.Text = Settings.Default.GitHubUsername;
            PersonalAccessTokenTextBox.Password = Settings.Default.PersonalAccessToken; // Fix for PasswordBox
        }

        private void BomGenerator_Click(object sender, RoutedEventArgs e)
        {
            BomWindow bomWindow = new BomWindow();
            bomWindow.Show();
        }


        public async Task LoadDashboardData()
        {
           
            string githubUsername = Settings.Default.GitHubUsername;
            string personalAccessToken = Settings.Default.PersonalAccessToken;
            string apiUrl = $"https://api.github.com/users/{githubUsername}/repos";

            int totalMaterials = 0;
            int lowStockCount = 0;
            List<string> lowStockMaterials = new List<string>();

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Add("User-Agent", "MyLabApp");
                    client.DefaultRequestHeaders.Add("Authorization", $"Bearer {personalAccessToken}");

                    string reposJson = await client.GetStringAsync(apiUrl);
                    JsonDocument reposDoc = JsonDocument.Parse(reposJson);
                    List<string> repoNames = new List<string>();

                    foreach (var repo in reposDoc.RootElement.EnumerateArray())
                    {
                        if (repo.TryGetProperty("name", out JsonElement repoNameElement))
                        {
                            repoNames.Add(repoNameElement.GetString());
                        }
                    }

                    totalMaterials = repoNames.Count;

                    foreach (string repoName in repoNames)
                    {
                        string jsonUrl = $"https://raw.githubusercontent.com/{githubUsername}/{repoName}/main/db.json";

                        try
                        {
                            string jsonData = await client.GetStringAsync(jsonUrl);
                            JsonDocument doc = JsonDocument.Parse(jsonData);
                            var material = doc.RootElement.GetProperty("inventory")[0];                           
                            var materialTitle = material.GetProperty("MaterialTitle");
                            string titleLSM = materialTitle.GetProperty("Name").GetString();
                            

                            if (material.TryGetProperty("MQNT", out JsonElement quantityElement))
                            {
                                
                                int quantity = quantityElement.GetInt32();

                                if (quantity < 8)
                                {
                                    LoadingOverlay.Visibility = Visibility.Collapsed;
                                    lowStockCount++;
                                    lowStockMaterials.Add(repoName + "  →  " + "{" + titleLSM  +"}"+ "  →   " + quantityElement);
                                    
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            

                            Console.WriteLine($"Skipping {repoName}: {ex.Message}");
                            
                        }
                    }

                    Dispatcher.Invoke(() =>
                    {
                        TotalMaterialsTextBlock.Text = totalMaterials.ToString();
                        LowStockTextBlock.Text = lowStockCount.ToString();

                        // Sort lowStockMaterials by extracting quantity (after last " → ")
                        var sortedList = lowStockMaterials
                            .Select(item => new
                            {
                                Text = item,
                                Quantity = int.Parse(item.Split("→").Last().Trim())
                            })
                            .OrderBy(x => x.Quantity)
                            .Select(x => x.Text)
                            .ToList();

                        LowStockList.ItemsSource = sortedList;

                        AnimateDashboard();
                    });

                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show($"Error loading data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadDashboardData();
        }

        private void AnimateDashboard()
        {
            DoubleAnimation fadeAnimation = new DoubleAnimation(0, 1, TimeSpan.FromSeconds(0.5));
            DashboardGrid.BeginAnimation(UIElement.OpacityProperty, fadeAnimation);
        }

        //For clipboard

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool OpenClipboard(IntPtr hWndNewOwner);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool CloseClipboard();

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool EmptyClipboard();

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern IntPtr SetClipboardData(uint uFormat, IntPtr data);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool IsClipboardFormatAvailable(uint format);

        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GlobalAlloc(uint uFlags, UIntPtr dwBytes);

        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GlobalLock(IntPtr hMem);

        [System.Runtime.InteropServices.DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GlobalUnlock(IntPtr hMem);

        private const uint CF_UNICODETEXT = 13;
        private const uint GMEM_MOVEABLE = 0x0002;


        private bool CopyToClipboard(string text)
        {
            if (!OpenClipboard(IntPtr.Zero))
                return false;

            EmptyClipboard();

            var bytes = (text.Length + 1) * 2; // UTF-16
            IntPtr hGlobal = GlobalAlloc(GMEM_MOVEABLE, (UIntPtr)bytes);
            if (hGlobal == IntPtr.Zero)
            {
                CloseClipboard();
                return false;
            }

            IntPtr target = GlobalLock(hGlobal);
            if (target == IntPtr.Zero)
            {
                CloseClipboard();
                return false;
            }

            System.Runtime.InteropServices.Marshal.Copy(text.ToCharArray(), 0, target, text.Length);
            GlobalUnlock(hGlobal);

            if (SetClipboardData(CF_UNICODETEXT, hGlobal) == IntPtr.Zero)
            {
                CloseClipboard();
                return false;
            }

            CloseClipboard();
            return true;
        }




        private void LowStockList_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (LowStockList.SelectedItem != null)
            {
                string selectedMaterial = LowStockList.SelectedItem.ToString();

                string repoNameOnly = selectedMaterial.Split(new[] { "→" }, StringSplitOptions.None)[0].Trim();

                if (CopyToClipboard(repoNameOnly))
                {
                    MessageBox.Show($"Copied: {repoNameOnly}", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Failed to copy to clipboard using fallback method.", "Clipboard Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }






        private void ShowDashboard()
        {
            MainGrid.Visibility = Visibility.Visible;
            ContentFrame.Visibility = Visibility.Collapsed;
            
            ContentFrame.Content = null;
            LoadDashboardData();
            LoadInventoryGrowthChart();
            

        }

        private void btnDashboard_Click(object sender, RoutedEventArgs e)
        {
            ShowDashboard();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            MainGrid.Visibility = Visibility.Collapsed;
            ContentFrame.Visibility = Visibility.Visible;
            ContentFrame.Navigate(new SearchPage());
        }

        private void btnAddMaterial_Click(object sender, RoutedEventArgs e)
        {
            MainGrid.Visibility = Visibility.Collapsed;
            ContentFrame.Visibility = Visibility.Visible;
            ContentFrame.Navigate(new AddMaterialPage());
        }

        private void btnEditMaterial_Click(object sender, RoutedEventArgs e)
        {
            MainGrid.Visibility = Visibility.Collapsed;
            ContentFrame.Visibility = Visibility.Visible;
            ContentFrame.Navigate(new EditMaterialPage());
        }

        private void btnDeleteMaterial_Click(object sender, RoutedEventArgs e)
        {
            MainGrid.Visibility = Visibility.Collapsed;
            ContentFrame.Visibility = Visibility.Visible;
            ContentFrame.Navigate(new DeleteMaterialPage());
        }

        private void btnAbout_Click(object sender, RoutedEventArgs e)
        {
            AboutDialog aboutDialog = new AboutDialog();
            aboutDialog.ShowDialog();
        }


    }
}
